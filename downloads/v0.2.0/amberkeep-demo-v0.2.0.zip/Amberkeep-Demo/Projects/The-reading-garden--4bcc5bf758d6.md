---
title: "The reading garden"
source_id: "demo-project-001"
source_kind: "project"
created: "2026-01-10T08:30:00Z"
updated: ""
source_file: "projects.json"
---

# The reading garden

Project fields and document data present in the supplied JSON:

```json
{
  "uuid": "demo-project-001",
  "name": "The reading garden",
  "description": "An entirely fictional project for trying Amberkeep.",
  "prompt_template": "Keep suggestions practical and separate facts from questions.",
  "created_at": "2026-01-10T08:30:00Z",
  "docs": [
    {
      "uuid": "demo-document-001",
      "filename": "Reading principles.md",
      "content": "Capture one idea per note. Keep the source. Link the next question.",
      "created_at": "2026-01-10T08:35:00Z"
    }
  ]
}
```

## Source

[Original source bytes](../Raw/a962f52a12fff6ca-projects-json.raw)

[[Amberkeep-Demo/Home|Export index]]

- Related note: [[Amberkeep-Demo/Conversations/A-small-knowledge-garden--215cbd0c9148|A-small-knowledge-garden--215cbd0c9148]]

- Related note: [[Amberkeep-Demo/Memory/Project-memory-demo-project-001--263b72a7126b|Project-memory-demo-project-001--263b72a7126b]]
