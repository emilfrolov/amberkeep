---
title: "preferences/reading.md"
source_id: "demo-account-001"
source_kind: "memory"
created: ""
updated: "2026-01-11T12:00:00Z"
source_file: "memories.json"
---

# preferences/reading.md

> Synthetic preference: review the reading list every Friday.

## Memory file metadata

```json
{
  "path": "preferences/reading.md",
  "updated_at": "2026-01-11T12:00:00Z"
}
```

## Source

[Original source bytes](../Raw/21a55457fa555b37-memories-json.raw)

[[Amberkeep-Demo/Home|Export index]]
