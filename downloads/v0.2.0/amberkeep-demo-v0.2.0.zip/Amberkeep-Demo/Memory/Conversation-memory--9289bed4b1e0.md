---
title: "Conversation memory"
source_id: "demo-account-001"
source_kind: "memory"
created: ""
updated: ""
source_file: "memories.json"
---

# Conversation memory

> This fictional user prefers concise explanations and Markdown notes.

## Source

[Original source bytes](../Raw/21a55457fa555b37-memories-json.raw)

[[Amberkeep-Demo/Home|Export index]]
