---
title: "Project memory demo-project-001"
source_id: "demo-project-001"
source_kind: "memory"
created: ""
updated: ""
source_file: "memories.json"
---

# Project memory demo-project-001

> The fictional reading garden separates questions, sources, and conclusions.

## Source

[Original source bytes](../Raw/21a55457fa555b37-memories-json.raw)

[[Amberkeep-Demo/Home|Export index]]

## Related project

- [[Amberkeep-Demo/Projects/The-reading-garden--4bcc5bf758d6|The-reading-garden--4bcc5bf758d6]]
