# Export report

This report covers the supplied input only. Export schemas vary; original uploaded attachments and other account data may not be supplied by Claude. The converter never connects to Claude or downloads remote files.

A rendered status means views were generated, not that every field has a dedicated Markdown view. Retained Raw files contain the original fields.

## Counts

- source_files: 6
- conversations: 2
- messages: 5
- projects: 1
- memory_notes: 3
- account_notes: 1
- data_notes: 1
- unknown_content_blocks: 1
- attachment_metadata_messages: 1
- raw_only_files: 1

## Warnings

- Attachment/file metadata occurs in messages. Original uploaded file bytes may be absent from Claude exports; no attachment URLs were fetched.
- Some message content types have no dedicated renderer. Their complete supplied JSON is shown as data; original source bytes are also retained.

## Source files

`manifest.json` maps every original path to a byte-identical Raw file with size and SHA-256. Raw files have a `.raw` suffix to keep imported Markdown and HTML from automatically rendering in Obsidian.

- attachments/demo-handout.txt — raw-only — [source bytes](Raw/e04298b6d8adb57b-demo-handout-txt.raw)
- conversations.json — rendered — [source bytes](Raw/177c9d62efa3e683-conversations-json.raw)
- memories.json — rendered — [source bytes](Raw/21a55457fa555b37-memories-json.raw)
- projects.json — rendered — [source bytes](Raw/a962f52a12fff6ca-projects-json.raw)
- settings.json — rendered — [source bytes](Raw/e9e1aabe0aae56cb-settings-json.raw)
- users.json — rendered — [source bytes](Raw/9eb18d9b8878a193-users-json.raw)

[[Amberkeep-Demo/Home|Export index]]
