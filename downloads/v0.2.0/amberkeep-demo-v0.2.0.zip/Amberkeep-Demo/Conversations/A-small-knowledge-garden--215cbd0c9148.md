---
title: "A small knowledge garden"
source_id: "demo-conversation-001"
source_kind: "conversation"
created: "2026-01-10T09:00:00Z"
updated: "2026-01-10T09:04:00Z"
source_file: "conversations.json"
---

# A small knowledge garden

Messages follow the order in the supplied export. Parent and branch metadata are preserved below; this view does not establish a single linear conversation.

## 1. human — 2026-01-10T09:00:00Z

> Help me organize a small reading project in Obsidian.

### Message metadata

```json
{
  "uuid": "demo-message-001",
  "sender": "human",
  "created_at": "2026-01-10T09:00:00Z"
}
```

## 2. assistant — 2026-01-10T09:01:00Z

> Start with an index, a reading list, and a note for each idea. Link related ideas as you go.

### Message metadata

```json
{
  "uuid": "demo-message-002",
  "sender": "assistant",
  "created_at": "2026-01-10T09:01:00Z",
  "parent_message_uuid": "demo-message-001"
}
```

## 3. human — 2026-01-10T09:04:00Z

> Here is an invented handout for this demo.

### Message metadata

```json
{
  "uuid": "demo-message-003",
  "sender": "human",
  "created_at": "2026-01-10T09:04:00Z",
  "attachments": [
    {
      "file_name": "demo-handout.txt",
      "file_type": "text/plain",
      "extracted_content": "A synthetic handout: keep sources, questions, and conclusions separate."
    }
  ]
}
```

## Conversation metadata

```json
{
  "uuid": "demo-conversation-001",
  "name": "A small knowledge garden",
  "created_at": "2026-01-10T09:00:00Z",
  "updated_at": "2026-01-10T09:04:00Z",
  "project_uuid": "demo-project-001"
}
```

## Source

[Original source bytes](../Raw/177c9d62efa3e683-conversations-json.raw)

[[Amberkeep-Demo/Home|Export index]]

## Related project

- [[Amberkeep-Demo/Projects/The-reading-garden--4bcc5bf758d6|The-reading-garden--4bcc5bf758d6]]
