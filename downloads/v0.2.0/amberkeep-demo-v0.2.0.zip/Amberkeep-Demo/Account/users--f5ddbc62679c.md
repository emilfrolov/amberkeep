---
title: "users"
source_id: "users.json"
source_kind: "account"
created: ""
updated: ""
source_file: "users.json"
---

# users

Fields from the supplied JSON, preserved as data:

```json
[
  {
    "uuid": "demo-account-001",
    "full_name": "Demo Reader",
    "email_address": "demo@example.invalid",
    "synthetic": true
  }
]
```

## Source

[Original source bytes](../Raw/9eb18d9b8878a193-users-json.raw)

[[Amberkeep-Demo/Home|Export index]]
