---
title: "settings"
source_id: "settings.json"
source_kind: "data"
created: ""
updated: ""
source_file: "settings.json"
---

# settings

Fields from the supplied JSON, preserved as data:

```json
{
  "synthetic": true,
  "example_setting": "This unrecognized file should be preserved and listed in the report."
}
```

## Source

[Original source bytes](../Raw/e9e1aabe0aae56cb-settings-json.raw)

[[Amberkeep-Demo/Home|Export index]]
