---
amberkeep_id: "memory:demo-workspace:demo-memory"
amberkeep_kind: "memory"
title: "Working preferences"
---

<!-- amberkeep:begin sha256=d4d9559056fab06ab2fa1bcd36b8033ebe4539553eb142406db973aab0af836b -->
# Working preferences

**Source-backed material.** Kept in the order returned by Claude; parent IDs do not prove a single linear conversation.

Source ID: memory:demo-workspace:demo-memory


## Links

- [[Amberkeep/Topics/storage--8d08a50af655|storage]] — mentions
- [[Amberkeep/Topics/local--4d122bac61ed|local]] — mentions

## Source text

### exported-memory

> Prefer local storage and explicit provenance when organizing notes.

^m-e616e22f8d09ba3f

<!-- amberkeep:end -->
