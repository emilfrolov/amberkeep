---
amberkeep_id: "project:demo-workspace:demo-project"
amberkeep_kind: "project"
title: "A personal knowledge library"
---

<!-- amberkeep:begin sha256=33d555bedcdb13e5f21ad4d663dcd6f32e5f5610fb0a7b20c86de83d0f56095d -->
# A personal knowledge library

**Source-backed material.** Kept in the order returned by Claude; parent IDs do not prove a single linear conversation.

Source ID: project:demo-workspace:demo-project


## Links

- [[Amberkeep/Topics/knowledge--dec2790eb59b|knowledge]] — mentions
- [[Amberkeep/Topics/storage--8d08a50af655|storage]] — mentions
- [[Amberkeep/Topics/source--84610887ff5a|source]] — mentions
- [[Amberkeep/Topics/local--4d122bac61ed|local]] — mentions
- [[Amberkeep/Topics/Evidence--f93ca08e7031|Evidence]] — mentions

## Source text

### project-description

> A fictional project connecting source conversations, local storage, and knowledge notes.

^m-c9046f7a37ad0ea7

### project-instructions

> Separate source evidence from interpretation.

^m-238fa28a94976c7d

<!-- amberkeep:end -->
