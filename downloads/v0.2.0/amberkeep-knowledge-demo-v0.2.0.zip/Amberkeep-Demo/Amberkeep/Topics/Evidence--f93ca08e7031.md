---
amberkeep_id: "topic:demo-workspace:evidence"
amberkeep_kind: "topic"
title: "Evidence"
---

<!-- amberkeep:begin sha256=208c6d66712f12e1f7a20c6290f3bfe1df75837e5ba77302b75721bdfa98da68 -->
# Evidence

**Recurring term — lexical index.** Linked because this wording recurs across synchronized sources. This is not a semantic synthesis.

- [[Amberkeep/Documents/Evidence principles--94791d8ff812|Evidence principles]] — title or project metadata.

- [[Amberkeep/Projects/A personal knowledge library--0d2616d376ea#^m-238fa28a94976c7d|A personal knowledge library]]

> Separate source evidence from interpretation.

<!-- amberkeep:end -->
