---
amberkeep_id: "topic:demo-workspace:local"
amberkeep_kind: "topic"
title: "local"
---

<!-- amberkeep:begin sha256=444217fde3c20b18e56c85071ca5580a80ab3199e9583081e2c2dd01e09b10d3 -->
# local

**Recurring term — lexical index.** Linked because this wording recurs across synchronized sources. This is not a semantic synthesis.

- [[Amberkeep/Conversations/Choosing local storage--50b1605d8b63#^m-018d98f9e48798c5|Choosing local storage]]

> We chose SQLite for local storage because the archive should work without a server.

- [[Amberkeep/Memory/Working preferences--da3f7c36b9b4#^m-e616e22f8d09ba3f|Working preferences]]

> Prefer local storage and explicit provenance when organizing notes.

- [[Amberkeep/Projects/A personal knowledge library--0d2616d376ea#^m-c9046f7a37ad0ea7|A personal knowledge library]]

> A fictional project connecting source conversations, local storage, and knowledge notes.

<!-- amberkeep:end -->
