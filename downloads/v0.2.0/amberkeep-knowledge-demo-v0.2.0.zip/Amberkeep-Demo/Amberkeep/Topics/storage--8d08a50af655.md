---
amberkeep_id: "topic:demo-workspace:storage"
amberkeep_kind: "topic"
title: "storage"
---

<!-- amberkeep:begin sha256=d7e2309a3048998426d6b02b8a12be350837a330479aa9290be8976b58a9b93a -->
# storage

**Recurring term — lexical index.** Linked because this wording recurs across synchronized sources. This is not a semantic synthesis.

- [[Amberkeep/Conversations/Making the knowledge useful--d0caf0d854f7#^m-6874f5853ab6dbf8|Making the knowledge useful]]

> SQLite is the storage layer; the knowledge graph connects concepts, decisions, and their source conversations.

- [[Amberkeep/Conversations/Choosing local storage--50b1605d8b63#^m-018d98f9e48798c5|Choosing local storage]]

> We chose SQLite for local storage because the archive should work without a server.

- [[Amberkeep/Memory/Working preferences--da3f7c36b9b4#^m-e616e22f8d09ba3f|Working preferences]]

> Prefer local storage and explicit provenance when organizing notes.

- [[Amberkeep/Projects/A personal knowledge library--0d2616d376ea#^m-c9046f7a37ad0ea7|A personal knowledge library]]

> A fictional project connecting source conversations, local storage, and knowledge notes.

<!-- amberkeep:end -->
