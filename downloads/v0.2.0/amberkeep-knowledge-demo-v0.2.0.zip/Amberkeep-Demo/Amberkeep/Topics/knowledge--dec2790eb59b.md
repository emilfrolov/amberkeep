---
amberkeep_id: "topic:demo-workspace:knowledge"
amberkeep_kind: "topic"
title: "knowledge"
---

<!-- amberkeep:begin sha256=afc2ffd9a04dba813de89d800f6daeb2ea5463e974de3435ba1ff153fc871031 -->
# knowledge

**Recurring term — lexical index.** Linked because this wording recurs across synchronized sources. This is not a semantic synthesis.

- [[Amberkeep/Conversations/Making the knowledge useful--d0caf0d854f7#^m-6874f5853ab6dbf8|Making the knowledge useful]]

> SQLite is the storage layer; the knowledge graph connects concepts, decisions, and their source conversations.

- [[Amberkeep/Documents/Evidence principles--94791d8ff812#^m-b7ed6e8198b968e1|Evidence principles]]

> Every knowledge claim should retain an exact source quotation.

- [[Amberkeep/Projects/A personal knowledge library--0d2616d376ea#^m-c9046f7a37ad0ea7|A personal knowledge library]]

> fictional project connecting source conversations, local storage, and knowledge notes.

<!-- amberkeep:end -->
