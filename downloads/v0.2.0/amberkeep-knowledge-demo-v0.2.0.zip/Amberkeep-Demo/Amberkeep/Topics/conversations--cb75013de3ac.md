---
amberkeep_id: "topic:demo-workspace:conversations"
amberkeep_kind: "topic"
title: "conversations"
---

<!-- amberkeep:begin sha256=d809141fc3fb16ea44b8785a5cf95cdd449e94f5c9310011de9de6bdb9ac35bd -->
# conversations

**Recurring term — lexical index.** Linked because this wording recurs across synchronized sources. This is not a semantic synthesis.

- [[Amberkeep/Conversations/Making the knowledge useful--d0caf0d854f7#^m-6874f5853ab6dbf8|Making the knowledge useful]]

> r; the knowledge graph connects concepts, decisions, and their source conversations.

- [[Amberkeep/Conversations/Choosing local storage--50b1605d8b63#^m-44b49cfb3aee22a6|Choosing local storage]]

> Use full-text search to find the original conversations. Keep source quotations alongside derived claims.

<!-- amberkeep:end -->
