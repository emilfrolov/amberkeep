---
amberkeep_id: "knowledge-concept:demo-workspace:source%20provenance"
amberkeep_kind: "concept"
title: "Source provenance"
---

<!-- amberkeep:begin sha256=76c6c19d44ad6d0fa3cc005d9a8ab8ee0ae8d9c5e9315fc770d190ad04d794c3 -->
# Source provenance

**AI-enriched knowledge.** These source-specific summaries are model interpretations, not independently verified facts. Quotations below are checked against the source text.

## From Making the knowledge useful

Each interpretation needs a traceable source quotation.

- [[Amberkeep/Conversations/Making the knowledge useful--d0caf0d854f7#^m-b6d241da000d81dd|Making the knowledge useful]]

> gives each interpretation a traceable source quotation

## From Choosing local storage

Derived claims should retain source quotations.

- [[Amberkeep/Conversations/Choosing local storage--50b1605d8b63#^m-44b49cfb3aee22a6|Choosing local storage]]

> Keep source quotations alongside derived claims.

<!-- amberkeep:end -->
