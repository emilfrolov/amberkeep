---
amberkeep_id: "knowledge-decision:demo-workspace:keep%20the%20archive%20local"
amberkeep_kind: "decision"
title: "Keep the archive local"
---

<!-- amberkeep:begin sha256=e5e6a3efafb3049c8a2eb23cc709abfa2ae197f4fba1040277614658aa7e8afa -->
# Keep the archive local

**AI-enriched knowledge.** These source-specific summaries are model interpretations, not independently verified facts. Quotations below are checked against the source text.

## From Choosing local storage

The archive is intended to work without a server.

- [[Amberkeep/Conversations/Choosing local storage--50b1605d8b63#^m-018d98f9e48798c5|Choosing local storage]]

> the archive should work without a server


## Links

- [[Amberkeep/Knowledge/SQLite--3ba3f87a6221|SQLite]] — uses (AI-suggested)

<!-- amberkeep:end -->
