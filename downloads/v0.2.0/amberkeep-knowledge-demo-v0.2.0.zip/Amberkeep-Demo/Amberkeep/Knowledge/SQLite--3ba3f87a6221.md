---
amberkeep_id: "knowledge-tool:demo-workspace:sqlite"
amberkeep_kind: "tool"
title: "SQLite"
---

<!-- amberkeep:begin sha256=b79bcb8547e4d623e446b3c04b31a994f53551f5db22e4b82b49a108381c054e -->
# SQLite

**AI-enriched knowledge.** These source-specific summaries are model interpretations, not independently verified facts. Quotations below are checked against the source text.

## From Making the knowledge useful

SQLite is described as the storage layer, separate from the graph.

- [[Amberkeep/Conversations/Making the knowledge useful--d0caf0d854f7#^m-6874f5853ab6dbf8|Making the knowledge useful]]

> SQLite is the storage layer

## From Choosing local storage

The fictional project selects SQLite for local storage.

- [[Amberkeep/Conversations/Choosing local storage--50b1605d8b63#^m-018d98f9e48798c5|Choosing local storage]]

> We chose SQLite for local storage because the archive should work without a server.

<!-- amberkeep:end -->
