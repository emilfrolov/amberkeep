---
amberkeep_id: "knowledge-concept:demo-workspace:knowledge%20graph"
amberkeep_kind: "concept"
title: "Knowledge graph"
---

<!-- amberkeep:begin sha256=349e9c2b410c64e3178a6159dd741bbc25220b23560805029b86059d29f88da8 -->
# Knowledge graph

**AI-enriched knowledge.** These source-specific summaries are model interpretations, not independently verified facts. Quotations below are checked against the source text.

## From Making the knowledge useful

The graph connects ideas, decisions, and the conversations that support them.

- [[Amberkeep/Conversations/Making the knowledge useful--d0caf0d854f7#^m-6874f5853ab6dbf8|Making the knowledge useful]]

> the knowledge graph connects concepts, decisions, and their source conversations


## Links

- [[Amberkeep/Knowledge/Source provenance--827c63d71e1e|Source provenance]] — depends on (AI-suggested)
- [[Amberkeep/Knowledge/SQLite--3ba3f87a6221|SQLite]] — uses (AI-suggested)

<!-- amberkeep:end -->
