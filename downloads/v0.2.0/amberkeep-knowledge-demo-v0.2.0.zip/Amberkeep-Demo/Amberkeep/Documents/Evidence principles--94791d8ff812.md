---
amberkeep_id: "document:demo-workspace:demo-project%2Fdemo-document"
amberkeep_kind: "document"
title: "Evidence principles"
---

<!-- amberkeep:begin sha256=4ce5ca4cc0220bbcee2e025c154e80a74bc04218b46288341587abf9d32c2475 -->
# Evidence principles

**Source-backed material.** Kept in the order returned by Claude; parent IDs do not prove a single linear conversation.

Source ID: document:demo-workspace:demo-project%2Fdemo-document


## Links

- [[Amberkeep/Projects/A personal knowledge library--0d2616d376ea|A personal knowledge library]] — belongs to
- [[Amberkeep/Topics/knowledge--dec2790eb59b|knowledge]] — mentions
- [[Amberkeep/Topics/source--84610887ff5a|source]] — mentions
- [[Amberkeep/Topics/Evidence--f93ca08e7031|Evidence]] — mentions

## Source text

### project-document

> Every knowledge claim should retain an exact source quotation.

^m-b7ed6e8198b968e1

<!-- amberkeep:end -->
