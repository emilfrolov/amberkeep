---
amberkeep_id: "conversation:demo-workspace:links"
amberkeep_kind: "conversation"
title: "Making the knowledge useful"
---

<!-- amberkeep:begin sha256=b9036aaa51ff13d767e75c9d9382157131e9c05c102550f228af5aee32ea5e32 -->
# Making the knowledge useful

**Source-backed material.** Kept in the order returned by Claude; parent IDs do not prove a single linear conversation.

Source ID: conversation:demo-workspace:links

Source updated: 2026-11-08T11:00:00Z


## Links

- [[Amberkeep/Projects/A personal knowledge library--0d2616d376ea|A personal knowledge library]] — belongs to
- [[Amberkeep/Topics/knowledge--dec2790eb59b|knowledge]] — mentions
- [[Amberkeep/Topics/storage--8d08a50af655|storage]] — mentions
- [[Amberkeep/Topics/source--84610887ff5a|source]] — mentions
- [[Amberkeep/Topics/conversations--cb75013de3ac|conversations]] — mentions

## Extracted knowledge

- [[Amberkeep/Knowledge/SQLite--3ba3f87a6221|SQLite]]
- [[Amberkeep/Knowledge/Knowledge graph--56781074128f|Knowledge graph]]
- [[Amberkeep/Knowledge/Source provenance--827c63d71e1e|Source provenance]]

## Source text

### human

> SQLite is the storage layer; the knowledge graph connects concepts, decisions, and their source conversations.

^m-6874f5853ab6dbf8

### assistant

> A useful knowledge graph links related ideas and gives each interpretation a traceable source quotation.

^m-b6d241da000d81dd

Parent source message: links-1

<!-- amberkeep:end -->
