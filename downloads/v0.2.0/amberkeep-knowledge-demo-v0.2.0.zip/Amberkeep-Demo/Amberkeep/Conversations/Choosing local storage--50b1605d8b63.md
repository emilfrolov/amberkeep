---
amberkeep_id: "conversation:demo-workspace:storage"
amberkeep_kind: "conversation"
title: "Choosing local storage"
---

<!-- amberkeep:begin sha256=41c585ea2c91573db23394334f43c32003d9455a9ffeed90c5d5b8991bf4b7d9 -->
# Choosing local storage

**Source-backed material.** Kept in the order returned by Claude; parent IDs do not prove a single linear conversation.

Source ID: conversation:demo-workspace:storage

Source updated: 2026-11-08T10:00:00Z


## Links

- [[Amberkeep/Projects/A personal knowledge library--0d2616d376ea|A personal knowledge library]] — belongs to
- [[Amberkeep/Topics/storage--8d08a50af655|storage]] — mentions
- [[Amberkeep/Topics/source--84610887ff5a|source]] — mentions
- [[Amberkeep/Topics/local--4d122bac61ed|local]] — mentions
- [[Amberkeep/Topics/conversations--cb75013de3ac|conversations]] — mentions

## Extracted knowledge

- [[Amberkeep/Knowledge/SQLite--3ba3f87a6221|SQLite]]
- [[Amberkeep/Knowledge/Keep the archive local--e0a7fdebf600|Keep the archive local]]
- [[Amberkeep/Knowledge/Source provenance--827c63d71e1e|Source provenance]]

## Source text

### human

> We chose SQLite for local storage because the archive should work without a server.

^m-018d98f9e48798c5

### assistant

> Use full-text search to find the original conversations. Keep source quotations alongside derived claims.

^m-44b49cfb3aee22a6

Parent source message: storage-1

<!-- amberkeep:end -->
