# Amberkeep knowledge graph demo

Entirely invented sources and hand-authored semantic fixtures; not a real account export or a claim that a model generated this demo.

Open [[Knowledge Map.canvas|the knowledge map]] or Obsidian’s Graph view to explore the linked notes. Open this directory itself as a vault; the managed notes are inside `Amberkeep/`.

The two invented conversations share SQLite and source provenance. Semantic fixtures contain exact source quotes and are checked by the same validator used for model output. Additional unanalysed sources remain explicitly pending.
